```markdown
# Design System Strategy: Editorial Intelligence

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Architectural Monolith."** 

Unlike standard SaaS platforms that rely on soft bubbles and friendly illustrations, this system is built on the principles of high-end editorial design and brutalist precision. We are creating a digital environment for **Replyd** that feels like a premium physical space—an obsidian gallery where AI isn't just a utility, but a sophisticated force. 

We break the "template" look by leaning into **intentional asymmetry**. Layouts should feel "unbalanced" yet mathematically perfect, using large-scale typography as a structural element rather than just a medium for copy. Elements should overlap, breaking the traditional "box-in-box" containment to create a sense of depth and motion.

## 2. Colors & Surface Philosophy
The palette is rooted in deep obsidian tones, punctuated by the high-voltage energy of **Electric Emerald**.

### Surface Hierarchy & Nesting
To achieve a bespoke feel, we move away from flat black. We use the "Surface Tier" system to create a sense of physical layering:
*   **Base Layer:** `surface` (#0e0e0e) for the primary canvas.
*   **Sunken Elements:** Use `surface-container-lowest` (#000000) for deep-set areas like footer zones or recessed code blocks.
*   **Elevated Layers:** Use `surface-container` (#1a1919) and `surface-container-high` (#201f1f) to create "stacked" paper effects.

### The "No-Line" Rule
Explicitly prohibit 1px solid borders for sectioning content. Boundaries must be defined through background color shifts or the **"Ghost Border"** fallback. Section transitions should feel like a change in material rather than a line on a page.

### The "Glass & Gradient" Rule
To add "soul" to the obsidian base:
*   **Signature Textures:** Use a subtle linear gradient on primary CTAs transitioning from `primary` (#a2ffbf) to `primary-container` (#00fd93) at a 135-degree angle.
*   **Glassmorphism:** Floating navigation bars or modal overlays must use `surface-variant` at 40% opacity with a `20px` backdrop-blur to allow the content beneath to "bleed" through, softening the brutalist edges.

## 3. Typography
Typography is our primary visual asset. It dictates the architectural rhythm of the page.

*   **Display & Headline (Space Grotesk):** These are the "beams" of our structure. Use `display-lg` with tight tracking (-0.02em) to create a sense of massive, confident authority.
*   **Body (Manrope):** Chosen for its Swiss-style neutrality. It provides a functional contrast to the expressive headlines.
*   **Functional Labels (Space Grotesk + All Caps):** Use `label-sm` with 0.1rem letter spacing for category tags, overlines, and small metadata. This "monospaced-adjacent" look conveys an engineered, high-tech precision.

## 4. Elevation & Depth
Depth in this design system is achieved through **Tonal Layering** rather than traditional structural lines.

*   **The Layering Principle:** Stack `surface-container-low` components on a `surface` background to create a soft, natural lift. Avoid drop shadows where possible; the color shift should do the work.
*   **Ambient Shadows:** When a floating element (like a floating action menu) is required, use a shadow with a 60px blur, 0% spread, and the color `on-background` at 4% opacity. This mimics natural light falling on a matte surface.
*   **Ghost Borders:** If a boundary is required for accessibility, use the `outline-variant` (#494847) token at 15% opacity. It should be felt, not seen.
*   **Sharpness:** All containers follow a strict `0px` to `4px` radius rule. Sharp corners communicate a professional, "no-nonsense" AI experience.

## 5. Components

### Buttons
*   **Primary:** Solid `primary` (#a2ffbf) background, `on-primary` text. `0px` radius. Hover state: scale 1.02 with a `primary_dim` glow.
*   **Secondary:** `Ghost Border` (15% opacity) with `on-surface` text. No background color.
*   **Tertiary:** `label-md` styling with a 1px underline that expands from the center on hover.

### Input Fields
*   **State:** Rectangular, sharp corners. Background is `surface-container-low`.
*   **Focus:** The bottom border transforms from `outline-variant` to a 2px `primary` (Electric Emerald) line. No "glow" or "halo" effects.

### Cards & Lists
*   **Rule:** Forbid the use of divider lines.
*   **Execution:** Use `spacing-8` (2.75rem) of vertical white space to separate list items. For cards, use a subtle background shift to `surface-container-highest` only on hover.

### Signature Component: The "Data Monolith"
A bespoke component for Replyd: Large, high-contrast numerical data or AI confidence scores rendered in `display-lg`, featuring a vertical `primary` accent line (2px width) to the left, anchored to a `surface-container` background.

## 6. Do's and Don'ts

### Do
*   **Use Asymmetry:** Place a large headline on the left and a small functional label on the far right of the same row.
*   **Embrace Negative Space:** If a section feels "empty," leave it. Space is a premium material in this system.
*   **Layer Motion:** Use subtle Parallax (scrolling at 0.95x speed) for background abstract shapes to create depth.

### Don't
*   **No Rounded UI:** Do not use radii above 4px. Avoid the "pill" shape entirely.
*   **No Generic Icons:** Avoid thin-line icon packs. Use abstract geometric shapes or high-resolution photography/renders to represent concepts.
*   **No High-Contrast Borders:** Never use `on-surface` at 100% opacity for a border. It breaks the "Architectural Monolith" atmosphere.